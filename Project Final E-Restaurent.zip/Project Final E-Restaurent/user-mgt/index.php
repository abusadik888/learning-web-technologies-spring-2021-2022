<?php 

	header('location: views/login.php');

?>