function foodaddval() {

    var foodcode = document.getElementById("foodcode").value;

    var foodname = document.getElementById("foodname").value;

    var foodprice = document.getElementById("foodprice").value;

    var foodtype = document.getElementById("foodtype").value;

    if (foodcode == "") {
        document.getElementById("errorFcode").innerHTML = "Food Code Required";

    }
    else {
        document.getElementById("errorFcode").innerHTML = "";

    }
    if (foodname == "") {
        document.getElementById("errorFname").innerHTML = "Food Name Required";
    }
    else {
        document.getElementById("errorFname").innerHTML = "";
    }

    if (foodprice == "") {
        document.getElementById("errorFprice").innerHTML = "Food Price Required";

    }
    else {
        document.getElementById("errorFprice").innerHTML = "";

    }

    if (foodtype == "") {
        document.getElementById("errorFtype").innerHTML = "Food Type Required";
        return false;

    }
    else {
        document.getElementById("errorFtype").innerHTML = "";

    }
}