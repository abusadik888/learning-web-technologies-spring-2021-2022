function loginvalidation() {

    var username = document.getElementById("username").value;

    var password = document.getElementById("password").value;

    if (username == "") {
        document.getElementById("errorUname").innerHTML = "UserName Required";

    }
    else {
        document.getElementById("errorUname").innerHTML = "";

    }
    if (password == "") {
        document.getElementById("errorPassword").innerHTML = "Password Required";
        return false;
    }
    else {
        document.getElementById("errorPassword").innerHTML = "";
    }
}