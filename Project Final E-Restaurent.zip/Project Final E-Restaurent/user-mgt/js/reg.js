function regvalidation() {

    var username = document.getElementById("username").value;

    var password = document.getElementById("password").value;

    var email = document.getElementById("email").value;


    var name = document.getElementById("name").value;

    var location = document.getElementById("location").value;

    var phone = document.getElementById("phone").value;


    var image = document.getElementById("image").value;

    if (username == "") {
        document.getElementById("errorUname").innerHTML = "UserName Required";

    }
    else {
        document.getElementById("errorUname").innerHTML = "";

    }
    if (password == "") {
        document.getElementById("errorPassword").innerHTML = "Password Required";

    }
    else {
        document.getElementById("errorPassword").innerHTML = "";
    }
    if (email == "") {
        document.getElementById("errorEmail").innerHTML = "Email Required";
    }
    else {
        document.getElementById("errorEmail").innerHTML == "";
    }
    if (name == "") {
        document.getElementById("errorName").innerHTML = "Name Required";

    }
    else {
        document.getElementById("errorName").innerHTML = "";

    }
    if (location == "") {
        document.getElementById("errorLocation").innerHTML = "Locaation Required";

    }
    else {
        document.getElementById("errorLocation").innerHTML = "";
    }
    if (phone == "") {
        document.getElementById("errorPhone").innerHTML = "Phone Number Required";

    }
    else {
        document.getElementById("errorPhone").innerHTML = "";

    }
    if (image == "") {
        document.getElementById("errorImage").innerHTML = "Image Required";
        return false;
    }
    else {
        document.getElementById("errorImage").innerHTML = "";

    }
}