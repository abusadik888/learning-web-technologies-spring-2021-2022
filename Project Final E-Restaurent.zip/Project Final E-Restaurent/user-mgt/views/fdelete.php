
<html>
<head></head>
<body>
<fieldset>
<form method="POST" action="../controllers/fdeletecheck.php">
<table align="center">
	<tr>
		<th colspan = 3>Delete Food Menu</th>
	</tr>

	
	<tr>
		<td><b> Food Name </b></td>
		<td>:</td>
		<td><input type="text" name="foodname" value = ""></td>
	</tr>

	<tr>
		<td><b>Food Code </b></td>
		<td>:</td>
		<td><input type="number" name="foodcode" value = ""></td>
	</tr>

	<tr>
		<td align="center" colspan="3"><input type="submit" name="submit"value="Delete"></td>
	</tr>


</table>
</fieldset>
</body>
</html>