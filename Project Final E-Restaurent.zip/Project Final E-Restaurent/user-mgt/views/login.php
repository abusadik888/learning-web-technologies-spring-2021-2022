<?php 
include "../controllers/loginCheck.php";
	$error = "";
	
	if(isset($_GET['msg'])){
		if($_GET['msg'] == 'error'){
			$error = "invalid username/password";
		}
	}

?>

<html>
<head>
<link rel="stylesheet" href="css/style.css">
<script defer src="../js/login.js"></script>

</head>

<body>

           <section class="navbar">


            <div class="menu text-center">
            <ul>
					<li>
						<a href="../home.php">Home</a>
					</li>
					<li>
						<a href="contacts.php">Contacts</a>
					</li>
					<li>
						<a href="about.php">About</a>
					</li>
				</ul>
            </div>

            <div class="clearfix"></div>
        </div>
    </section>
	 <section class="login">
    <div class="container">
            <h2 class="text-center">Log in</h2>
            <center>
	<form id="form" method="POST" onsubmit="return loginvalidation() " action="../controllers/loginCheck.php">
		<table>
          <tr>

			<tr>
				<td><label for="username">Username</label></td>
				<td><input type="text" name="username" value="" id="username"></td>
				<td><p id="errorUname"></p></td>
			</tr>
			<tr>
				<td><label for="password">Password</label></td>
				<td><input type="password" name="password" value="" id="password"></td>
				<td><p id="errorPassword"></p></td>
			</tr>
			            <tr>
                <td><br>
                    <button class="btn btn-small btn-small-primary" type="submit" name="submit" value="Submit">
                        Login
                    </button>
                </td>
                
                <td>
                    <br>
                    <a class="btn btn-red btn-red-primary" href="reg.php">Register</a>
                    <br>
					<?=$error?>
                </td>
            </tr>
        </table>
        </form>
        <br>
        <br>
        <div id="error"></div>
        </center>
            </section>
		</table>
	</form>
</body>
</html>