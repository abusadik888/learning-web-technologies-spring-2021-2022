<html>
<head>
	<title>File upload</title>
</head>
<body>

		<form method="POST" action="check.php" enctype="multipart/form-data">
			Image: <input type="file" name="myfile">
					<input type="submit" name="submit" value="Submit">			
		</form>
</body>
</html>