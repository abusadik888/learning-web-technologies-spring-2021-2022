<?php
		require_once('headernormal.php');   
?>


    <section class="contacts">
    <div class="container">
        <Pre>
        <center><h2>HOURS & LOCATION</h2>
399B Shahid Baki Rd,
Dhaka 1219
+8801787713874
info@erestaurant.com

<b>Dine In</b>

Wednesday | Thursday | Sunday : 5.30 - 9.30 PM

Friday & Saturday : 5 - 10 PM

Sunday Lunch : 12.30 - 1.30 PM

Closed Monday & Tuesday

----------------



For additional information or inquires, please email <i> info@erestaurant.com .</i>
</center><pre>
    </div>
    </section>