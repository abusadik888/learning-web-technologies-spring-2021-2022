<html>
	<body>
	<fieldset>
		<table align="center">
			<tr>
				<th colspan = 3>This is your Profile</th>
			</tr>
			<tr>
				<td colspan = 3><center><img width="200px" height="200px" src=customer.jpg></center></td>
			</tr>
			<tr>
				<td><b>Name</b></td>
				<td><b>:</b></td>
				<td>xyz</td>
			</tr>
			<tr>
				<td><b>Customer Id</b></td>
				<td><b>:</b></td>
				<td>1****4</td>
			</tr>
			<tr>
				<td><b>User Name</b></td>
				<td><b>:</b></td>
				<td>xyz88</td>
			</tr>
			<tr>
				<td><b>Address</b></td>
				<td><b>:</b></td>
				<td>12/a Kuril dhaka</td>
			</tr>
			<tr>
				<td><b>Email</b></td>
				<td><b>:</b></td>
				<td>xyz@.com</td>
			</tr>
			<tr>
				<td><b>Contact number</b></td>
				<td><b>:</b></td>
				<td>017********</td>
			</tr>
		</table>
		</fieldset>
	</body>
</html>


