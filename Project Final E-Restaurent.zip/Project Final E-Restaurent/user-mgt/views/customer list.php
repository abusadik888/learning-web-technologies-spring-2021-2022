<html>
	<body>
		<table align="center" border=3>
			<tr>
				<th colspan = 5>Customer List </th>
			</tr>
			<tr>
				<td>Serial no </td>
				<td>Name</td>
				<td>Address</td>
				<td>Phone Number</td>
				<td>Sent Email </td>
			</tr>
			<tr>
				<td><center>01</center></td>
				<td><center>Sadik</center></td>
				<td><center>Badda</center></td>
				<td><center>017********</center></td>
				<td><p><a target="_blank" href="sent email.php">Sent email</a></p></td>
				
			</tr>
			<tr>
				<td><center>02</center></td>
				<td><center>Faysal</center></td>
				<td><center>Gulshan</center></td>
				<td><center>017********</center></td>
				<td><p><a target="_blank" href="sent email.php">Sent email</a></p></td>
			</tr>
			<tr>
				<td><center>03</center></td>
				<td><center>Lamia</center></td>
				<td><center>Banani</center></td>
				<td><center>017********</center></td>
				<td><p><a target="_blank" href="sent email.php">Sent email</a></p></td>
			</tr>
			<tr>
				<td><center>04</center></td>
				<td><center>Abijit</center></td>
				<td><center>Dhanmondi</center></td>
				<td><center>017********</center></td>
				<td><p><a target="_blank" href="sent email.php">Sent email</a></p></td>
			</tr>
			<tr>
				<td><center>05</center></td>
				<td><center>Durlov</center></td>
				<td><center>Bashundhara</center></td>
				<td><center>017********</center></td>
				<td><p><a target="_blank" href="sent email.php">Sent email</a></p></td>
			</tr>
			
		</table>
	</body>
</html>