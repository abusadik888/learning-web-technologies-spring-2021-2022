<?php
$id="";
$err_id="";
$rd="";
$err_rd="";
$offertype="";
$err_offertype="";
$offerdetails="";
$err_offerdetails="";
$err=false;
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		
		if(empty($_POST["id"]))
		{
			$err_id="*id Required";
			$err = true;
		}
		else
		{
			$id = $_POST["id"];
		}
		if(empty($_POST["rd"]))
		{
			$err_rd="*Requested date Required";
			$err=true;
		}
		else
		{
			$rd=$_POST["rd"];
		}
		if(!isset($_POST["offertype"]))
		{
			$err_offertype="* Request offer type Required";
			$err=true;
		}
		else
		{
			$shift=$_POST["shift"];
		}
		if(empty($_POST["offerdetails"])){
			$err_reason="*Offer Details Required";
			$err = true;
		}
		else
		{
			$reason = $_POST["reason"];
		}
		if(!$err)
		{
			echo $_POST["id"]."<br>";
			echo $_POST["rd"]."<br>";
			echo $_POST["shift"]."<br>";
			echo $_POST["reason"]."<br>";
		}
		

	}		
?>
<html>
	<body>
	<fieldset>
	<form action="" method="post">
		<table align="center">
			<tr>
				<th colspan = 3>For create new offer</th>
			</tr>

			<tr>
				<td><b>Enter your ID </b></td>
				<td>:</td>
				<td><input type="id" name="id" value = "<?php echo $id; ?>"placeholder="Your id here"></td>
				<td><span><?php echo $err_id;?></span></td>
			</tr>
			<tr>
				<td><b>Start date</b></td>
				<td>:</td>
				<td><input type="date" name="rd" value = "<?php echo $rd; ?>" placeholder="Your Requested date here"></td>
				<td><span><?php echo $err_rd;?></span></td>
			</tr>
			<tr>
				<td><b>Ending date</b></td>
				<td>:</td>
				<td><input type="date" name="rd" value = "<?php echo $rd; ?>" placeholder="Your Requested date here"></td>
				<td><span><?php echo $err_rd;?></span></td>
			</tr>
			<tr>
				<td><b>Offer Type</b></td>
				<td>:</td>
				<td><input type="radio" value = "Buy 1 Get 1" <?php if ($offertype == "Buy 1 Get 1") echo "checked"; ?> name="offertype" >Buy 1 Get 1<input type="radio" value = "10% Dis"<?php if ($offertype == "10% Dis") echo "checked"; ?> name="offertype">10% Dis</td>
				<td><span><?php echo $err_offertype;?></span></td>
			</tr>
			<tr>
				<td><b>Offer Details</b></td>
				<td>:</td>
				<td><textarea name="offferdetails" placeholder ="Offer Details Here"><?php echo $offerdetails; ?></textarea></td>
				<td><span><?php echo $err_offerdetails;?></span></td>
			</tr>
			<tr>
				<td align="center" colspan="3"><input type="submit" name="submit"value="Confirm"></td>
			</tr>
		</table>
	</form>
	</fieldset>
	</body>
</html>