
<html>
    <head>
	<title>Income</title>
<script>
		function income()
{

    var foodname = document.getElementById("foodname").value;

   var monthlysell = document.getElementById("monthlysell").value;

    if (foodname == "")
	{
        document.getElementById("errorFname").innerHTML = "Food Name Required";
        
    }
    else
	{
        document.getElementById("errorFname").innerHTML = "";

    }

   
    if (monthlysell == "")
	{
        document.getElementById("errorMsell").innerHTML = "Monthly Sell Required";
        
    }
    else
	{
        document.getElementById("errorMsell").innerHTML = "";
    }

	if (month == "")
	{
        document.getElementById("errorMonth").innerHTML = "Month Required";
        return false;
    }
    else
	{
        document.getElementById("errorMonth").innerHTML = "";
	}
}
</script>

    </head>
	<body>
	<fieldset>
	<form action="../controllers/incomecheck.php" method="post" onsubmit="return income() ">
		<table align="center">
			<tr>
				<th colspan = 3>Income Recood</th>
			</tr>
			<tr>
				<td><b>Food Name </b></td>
				<td>:</td>
				<td><input type="text" name="foodname" value = "" placeholder="Food name here " id="foodname"></td>
				<td><p id="errorFname"></p></td>
			</tr>
			<tr>
				<td><b>Monthly Sell </b></td>
				<td>:</td>
				<td><input type="SellPrice" name="SellPrice" value = ""placeholder="Your Sell price here" id="monthlysell"></td>
				<td><p id="errorSprice"></p></td>
			</tr>

			<tr>
				<td><b>Month</b></td>
				<td>:</td>
				<td>
					<select name="month" id="month">
					    <option selected disabled value ="">SELECT</option>
						<option value ="JANUARY">JANUARY</option>
						<option value ="FEBRUARY">FEBRUARY</option>
						<option value ="MARCH">MARCH</option>
						<option value ="APRIL">APRIL</option>
						<option value ="MAY">MAY</option>
						<option value ="JUNE">JUNE</option>
						<option value ="JULY">JULY</option>
						<option value ="AUGUST">AUGUST</option>
						<option value ="SEPTEMBER">SEPTEMBER</option>
						<option value ="OCTOBER">OCTOBER</option>
						<option value ="NOVEMBER">NOVEMBER</option>
						<option value ="DECEMBER">DECEMBER</option>
				</td>
				<td><p id="errorMonth"></p></td>
			</tr>
			<tr>
			    <form method="POST" action="check.php" enctype="multipart/form-data">


			<tr>
				<td align="center" colspan="3"><input type="submit" name="submit"value="Confirm"></td>
			</tr>
					
		</form>
		</table>
	</form>
	</fieldset>
	</body>
</html>