<html>

<head>
	<title>Food Add</title>
	<link rel="stylesheet" href="css/style.css">
	<script defer src="../js/fadd.js"></script>

	<script type="text/javascript">
		

		function ajax() {
		

			let foodcode = document.getElementById('foodcode').value;
			let foodname = document.getElementById('foodname').value;
			let foodprice = document.getElementById('foodprice').value;
			let foodtype = document.getElementById('foodtype').value;
			let http = new XMLHttpRequest();
			http.open('POST', 'ajax.php', true);
			http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			http.send('foodcode=' + foodcode + '&foodname=' + foodname + '&foodprice=' + foodprice + '&foodtype=' + foodtype);

			http.onreadystatechange = function() {

				if (this.readyState == 4 && this.status == 200) {
					document.getElementById('foodlist').innerHTML = this.responseText;
					document.getElementById('errorFcode').innerHTML = "";
					document.getElementById('errorFname').innerHTML = "";
					document.getElementById('errorFprice').innerHTML = "";
					document.getElementById('errorFtype').innerHTML = "";
				}
			}
		}
	</script>
</head>

<body>
	<section class="navbar">


		<div class="menu text-center">
			<ul>
				<li>
					<a href="fedit.php">Food Edit</a>
				</li>
				<li>
					<a href="fdelete.php">Food Delete</a>
				</li>
			</ul>
		</div>

		<section class="register">
			<div class="container">
				<h2 class="text-center">ADD FOOD</h2>
				<center>
					<form method="POST" onsubmit="return foodaddval() " action="../controllers/faddcheck.php">
						<table align="center">
							<tr>


							<tr>
								<td><label for="foodcode">Food Code</label></td>
								<td><input type="number" name="foodcode" value="" id="foodcode"></td>
								<td>
									<p id="errorFcode"></p>
								</td>
							</tr>
							<tr>
								<td><label for="foodname">Food name</label></td>
								<td><input type="text" name="foodname" value="" id="foodname"></td>
								<td>
									<p id="errorFname"></p>
								</td>
							</tr>
							<tr>
								<td><label for="foodprice">Food Price</label></td>
								<td><input type="number" name="foodprice" value="" id="foodprice"></td>
								<td>
									<p id="errorFprice"></p>
								</td>
							</tr>
							<tr>
								<td><label for="foodtype">Food Type</label></td>
								<td><input type="text" name="foodtype" value="" id="foodtype"></td>
								<td>
									<p id="errorFtype"></p>
								</td>
							</tr>
							<tr>
								<td><br>

									<!-- <button class="btn btn-small btn-small-primary" type="submit" name="submit" value="Submit" onClick="ajax()">
										Submit
									</button> -->
								</td>
							</tr>
						</table>
					</form>
					</table>
					<button onclick="ajax()">SUBMIT</button>
					<div id="foodlist"></div>
					<br>
					<br>
					<div id="error"></div>
				</center>

</body>

</html>