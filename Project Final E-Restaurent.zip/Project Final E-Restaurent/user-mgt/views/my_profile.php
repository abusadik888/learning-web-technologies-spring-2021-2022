<html>
	<?php 
		$name = "Sadik";
		$id= "19-39912-1"
	?>
	<head></head>
	<body>
		<h1 align="center">My profile</h1>
		<table align="center">
			<tr>
				<td><?php echo $name;?></td>
				<td><?php echo $id;?></td>
			</tr>
		</table>
	</body>
</html>