<html>
	<body>
		<table border= 3 align="center">
			<tr>
				<th colspan = 6>Panding Order</th>
			</tr>
			<tr>
			    <td><b>Order Id</b></td>
				<td><b>Order Items</b></td>
				<td><b>Price</b></td>
				<td><b>Payment Method</b></td>
				<td><b>Quantity</b></td>
				<td><b>Customer Profile</b></td>
			</tr>
			<tr>
			    <td><b>111</b></td>
				<td><b>Burger and Sandwich</b></td>
				<td>450tk</td>
				<td><center>COD</center></td>
				<td><center>1</center></td>
				<td><p><a target="_blank" href="customer profile.php">View Profile</a></p></td>
			</tr>
			<tr>
			    <td><b>102</b></td>
				<td><b>Sandwich</b></td>
				<td>175tk</td>
				<td><center>COD</center></td>
				<td><center>1</center></td>
				<td><p><a target="_blank" href="customer profile.php">View Profile</a></p></td>
			</tr>
			<tr>
			    <td><b>103</b></td>
				<td><b>Burger</b></td>
				<td>275tk</td>
				<td><center>COD</center></td>
				<td><center>1</center></td>
				<td><p><a target="_blank" href="customer profile.php">View Profile</a></p></td>
			</tr>
			<tr>
			    <td><b>104</b></td>
				<td><b>Pizza</b></td>
				<td>875tk</td>
				<td><center>Card</center></td>
				<td><center>1</center></td>
				<td><p><a target="_blank" href="customer profile.php">View Profile</a></p></td>
			</tr>
			<tr>
			    <td><b>105</b></td>
				<td><b>Pasta</b></td>
				<td>275tk</td>
				<td><center>COD</center></td>
				<td><center>1</center></td>
				<td><p><a target="_blank" href="customer profile.php">View Profile</a></p></td>
			</tr>
			<tr>
			    <td><b>106</b></td>
				<td><b>Nachos</b></td>
				<td>175tk</td>
				<td><center>Bkash</center></td>
				<td><center>1</center></td>
				<td><p><a target="_blank" href="customer profile.php">View Profile</a></p></td>
			</tr>
			<tr>
			    <td><b>107</b></td>
				<td><b>Momos</b></td>
				<td>150tk</td>
				<td><center>COD</center></td>
				<td><center>1</center></td>
				<td><p><a target="_blank" href="customer profile.php">View Profile</a></p></td>
			</tr>
		</table>
	</body>
</html>



