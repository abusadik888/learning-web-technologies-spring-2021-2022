<?php
require_once('../models/usermodel.php');
if (isset($_POST['foodcode']) && isset($_POST['foodname']) && isset($_POST['foodprice']) && isset($_POST['foodtype'])) {
	$foodcode = $_POST['foodcode'];
	$foodname = $_POST['foodname'];
	$foodprice = $_POST['foodprice'];
	$foodtype = $_POST['foodtype'];
	if (addfood($foodcode, $foodname, $foodprice, $foodtype)) {
		echo "
	<br>
		<table>
			<tr>
				<td>
				Food Code is: " . $_POST['foodcode'] . "
				</td>
			</tr>
			<tr>
				<td>
				Food Name is: " . $_POST['foodname'] . "
				</td>
			</tr>
			<tr>
				<td>
				Food Price is: " . $_POST['foodprice'] . "
				</td>
			</tr>
			<tr>
				<td>
				Food Type is: " . $_POST['foodtype'] . "
				</td>
			</tr>
		</table>
	";
	} else {
		echo " something went wrong";
	}
}
