
<html>
<head>
    <link rel="stylesheet" href="style.css">


</head>
<body>

<form method="POST" onsubmit="return loginvalidation()" action="">
		<table align="center">

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">ERestaurant</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="#">HOME</a></li>
                    <li><a href="food menu.php">Food Menu</a></li>
                    <li><a href="customer list.php">Customer</a></li>
                    <li><a href="post new offer.php">Create Offer</a></li>
                    <li><a href="Profile.php">Profile</a></li>
                    <li><a href="Income Record.php">Income</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contacts.php">Contacts</a></li>
                    <li><a href="ajax.php">My Profile</a></li
                </ul>
            </div>



</body>
</html>