<html>
	<body>
	<fieldset>
		<table align="center">
			<tr>
				<th colspan = 3>This is your Profile</th>
			</tr>
			<tr>
				<td colspan = 3><center><img width="200px" height="200px" src=xyz.jpg></center></td>
			</tr>
			<tr>
				<td><b>Name</b></td>
				<td><b>:</b></td>
				<td>Sadik</td>
			</tr>
			<tr>
				<td><b>Id</b></td>
				<td><b>:</b></td>
				<td>19-*****-1</td>
			</tr>
			<tr>
				<td><b>User Name</b></td>
				<td><b>:</b></td>
				<td>sadik_xyz</td>
			</tr>
			<tr>
				<td><b>Address</b></td>
				<td><b>:</b></td>
				<td>12/a Badda dhaka</td>
			</tr>
			<tr>
				<td><b>Email</b></td>
				<td><b>:</b></td>
				<td>sadik@xyz.com</td>
			</tr>
			<tr>
				<td><b>cell number</b></td>
				<td><b>:</b></td>
				<td>017********</td>
			</tr>
			<tr>
				<td><b>NID Number</b></td>
				<td><b>:</b></td>
				<td>1234567890</td>
			</tr>
			<tr>
				<td><b>Joining Date</b></td>
				<td><b>:</b></td>
				<td>dd/mm/yyy</td>
			</tr>
			<tr>
				<td><b>Post</b></td>
				<td><b>:</b></td>
				<td>Manager</td>
			</tr>
			<tr>
				<td><b>Salary</b></td>
				<td><b>:</b></td>
				<td>35000</td>
			</tr>
		</table>
		</fieldset>
	</body>
</html>


