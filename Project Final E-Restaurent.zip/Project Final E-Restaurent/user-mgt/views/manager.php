<html>
	<body>
		<table border=3 align="center">
			<tr>
				<th>This is a Manager account</th>
			<tr>
			<tr>
				<td><b><a href="Profile.php">Profile</a></b></td>
			</tr>
			<tr>
				<td><b><a href="customer list.php">Customer list</a></b></td>
			</tr>
			
			<tr>
				<td><b><a href="post new offer.php">New offer</a></b></td>
			</tr>
			<tr>
				<td><b><a href="food menu.php">Food menu</a></b></td>
			</tr>
			<tr>
				<td><b><a href="Income Record.php">Income Record</a></b></td>
			</tr>
			<tr>
				<td><b><a href="company profile.php">Company Profile</a></b></td>
			</tr>
			<tr>
				<td><b><a href="panding order.php">Panding Order</a></b></td>
			</tr>
		</table>
	</body>
</html>