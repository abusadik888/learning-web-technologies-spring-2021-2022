<html>
	<body>
	<fieldset>
		<table align="center">
			<tr>
				<th colspan = 3>This is Company Profile</th>
			</tr>
			<tr>
				<td colspan = 3><center><img width="200px" height="200px" src=logo.jpg></center></td>
			</tr>
			<tr>
				<td><b>Company Name</b></td>
				<td><b>:</b></td>
				<td>E  Restaurant</td>
			</tr>
			<tr>
				<td><b>Tin Number</b></td>
				<td><b>:</b></td>
				<td>19******1</td>
			</tr>
			<tr>
				<td><b>Bin Number</b></td>
				<td><b>:</b></td>
				<td>34*******2</td>
			</tr>
			<tr>
				<td><b>Company Address</b></td>
				<td><b>:</b></td>
				<td>12/a Gulshan-2 dhaka</td>
			</tr>
			<tr>
				<td><b>Company Email</b></td>
				<td><b>:</b></td>
				<td>erestaurant@xyz.com</td>
			</tr>
			<tr>
				<td><b>Hotline Number</b></td>
				<td><b>:</b></td>
				<td>096********</td>
			</tr>
			<tr>
				<td><b>Since</b></td>
				<td><b>:</b></td>
				<td>dd/mm/yyy</td>
			</tr>
			<tr>
				<td><b>Owner</b></td>
				<td><b>:</b></td>
				<td>xyz</td>
			</tr>
		
		</table>
		</fieldset>
	</body>
</html>


