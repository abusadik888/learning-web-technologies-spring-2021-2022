<html>
	<?php 
		$name = "Sabbir";
	?>
	<head></head>
	<body>
		<h1 align="center">My profile</h1>
		<table align="center">
			<tr>
				<td><?php echo $name;?></td>
			</tr>
		</table>
	</body>
</html>