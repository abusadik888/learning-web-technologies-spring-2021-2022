<html>
<head>
	<title>Food Edit</title>

<script>
	function foodeditval()
{

   var foodname = document.getElementById("foodname").value;

	var foodprice = document.getElementById("foodprice").value;

    if (foodname == "")
	{
        document.getElementById("errorFname").innerHTML = "Food Name Required";
    }
    else
	{
        document.getElementById("errorFname").innerHTML = "";
    }

	if (foodprice == "")
	{
        document.getElementById("errorFprice").innerHTML = "Food Price Required";
		return false;
        
    }
    else
	{
        document.getElementById("errorFprice").innerHTML = "";

    }


}
</script>

</head>
<body>
	<form method="POST" onsubmit="return foodeditval() " action="../controllers/feditcheck.php">
		<table align="center">
   <tr>
		<th colspan = 3>Give these information to Change Food Price</th>
	</tr>
        
			<tr>
				<td>Food Name</td>
				<td><input type="text" name="foodname" value="" id="foodname"></td>
				<td><p id="errorFname"></p></td>
			</tr>
			<tr>
				<td>New Price</td>
				<td><input type="number" name="foodprice" value="" id="foodprice"></td>
				<td><p id="errorFprice"></p></td>
			</tr>
			<tr>
				<td></td>
				<td>
					<input type="submit" name="submit" value="Submit">
					<br>
				</td>
			</tr>
		</table>
	</form>
</body>
</html>