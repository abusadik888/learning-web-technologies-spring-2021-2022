<html>
<head>
	<title>Signup</title>
    <link rel="stylesheet" href="css/style.css">
	<script defer src="../js/reg.js"></script>

</head>

<body>
	 <section class="register">
    <div class="container">
            <h2 class="text-center">Register</h2>
            <center>
	<form id="form" method="POST" onsubmit="return regvalidation() " action="../controllers/regCheck.php">
		<table>
          <tr>

		<th
			colspan = 3>Give these information to Signup</th>
		</tr>
			<tr>
				<td><label for="username">Username</label></td>
				<td><input type="text" name="username" value="" id="username"></td>
				<td><p id="errorUname"></p></td>
			</tr>
			<tr>
				<td><label for="password">Password</label></td>
				<td><input type="password" name="password" value="" id="password"></td>
				<td><p id="errorPassword"></p></td>
			</tr>
			<tr>
				<td><label for="email">Email</label></td>
				<td><input type="email" name="email" value="" id="email"></td>
				<td><p id="errorEmail"></p></td>
			</tr>
			<tr>
				<td><label for="name">Name</label></td>
				<td><input type="text" name="name" value="" id="name"></td>
				<td><p id="errorName"></p></td>
			</tr>
			<tr>
				<td><label for="location">Location</label></td>
				<td><input type="text" name="location" value="" id="location"></td>
				<td><p id="errorLocation"></p></td>
			</tr>
			<tr>
				<td><label for="phone">Phone</label></td>
				<td><input type="number" name="phone" value="" id="phone"></td>
				<td><p id="errorPhone"></p></td>
			</tr>
			<tr>
				<td><label for="image">Profile Picture</label></td>
				<td><input type="file" name="image" value="" id="image"></td>
				<td><p id="errorImage"></p></td>
			</tr>
		            <tr>
                <td><br>
                    <button class="btn btn-small btn-small-primary" type="submit" name="submit" value="Submit">
                        Register
                    </button>
                </td>
                
                <td>
                    <br>
                    <a class="btn btn-red btn-red-primary" href="login.php">Login</a>
                </td>
            </tr>
        </table>
        </form>
        <br>
        <br>
        <div id="error"></div>
        </center>
        
    </section>

</body>
</html>