<html>
	<body>
		<table border= 3 align="center">
			<tr>
				<th colspan = 5>Food Menu</th>
			</tr>
			<tr>
			    <td><b>Food Code</b></td>
				<td><b>Food Name</b></td>
				<td colspan = 4><b>Price</b></td>
			</tr>
			<tr>
			    <td><b>101</b></td>
				<td><b>Cream of Mushroom Soup</b></td>
				<td>375tk</td>
				<td><p><a target="_blank" href="fedit.php">Edit</a></p></td>
				<td><p><a target="_blank" href="fdelete.php">Delete</a></p></td>
			</tr>
			<tr>
			    <td><b>102</b></td>
				<td><b>Sandwich</b></td>
				<td>175tk</td>
				<td><p><a target="_blank" href="fedit.php">Edit</a></p></td>
				<td><p><a target="_blank" href="fdelete.php">Delete</a></p></td>
			</tr>
			<tr>
			    <td><b>103</b></td>
				<td><b>Burger</b></td>
				<td>275tk</td>
				<td><p><a target="_blank" href="fedit.php">Edit</a></p></td>
				<td><p><a target="_blank" href="fdelete.php">Delete</a></p></td>
			</tr>
			<tr>
			    <td><b>104</b></td>
				<td><b>Pizza</b></td>
				<td>875tk</td>
				<td><p><a target="_blank" href="fedit.php">Edit</a></p></td>
				<td><p><a target="_blank" href="fdelete.php">Delete</a></p></td>
			</tr>
			<tr>
			    <td><b>105</b></td>
				<td><b>Pasta</b></td>
				<td>275tk</td>
				<td><p><a target="_blank" href="fedit.php">Edit</a></p></td>
				<td><p><a target="_blank" href="fdelete.php">Delete</a></p></td>
			</tr>
			<tr>
			    <td><b>106</b></td>
				<td><b>Nachos</b></td>
				<td>175tk</td>
				<td><p><a target="_blank" href="fedit.php">Edit</a></p></td>
				<td><p><a target="_blank" href="fdelete.php">Delete</a></p></td>
			</tr>
			<tr>
			    <td><b>107</b></td>
				<td><b>Momos</b></td>
				<td>150tk</td>
				<td><p><a target="_blank" href="fedit.php">Edit</a></p></td>
				<td><p><a target="_blank" href="fdelete.php">Delete</a></p></td>
			</tr>
<tr>
				<td><b><a href="addfoodmenu.php">Add Food</a></b></td>
			</tr>
		</table>
		
	</body>
</html>


