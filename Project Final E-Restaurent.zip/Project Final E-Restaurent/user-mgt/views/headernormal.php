
<html>
<head>
  
    <title>E-restaurant</title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style.css">
    <script defer src="../controller/validation/js/loginscript.js"></script>
</head>
<body>
      <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">ERestaurant</h2>
            </div>


            <div class="menu text-right">
            <ul>
					<li><a href="#">HOME</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="customer list.php">Customer</a></li>
                    <li><a href="post new offer.php">Create Offer</a></li>
                    <li><a href="Profile.php">Profile</a></li>
                    <li><a href="food menu.php">Food Menu</a></li>
                    <li><a href="Income Record.php">Income</a></li>
				</ul>
            </div>

            <div class="clearfix"></div>
        </div>
   </body>
   </html