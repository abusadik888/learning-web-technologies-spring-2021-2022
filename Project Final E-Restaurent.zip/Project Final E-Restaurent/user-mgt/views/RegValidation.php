<html>
	<body>
		<fieldset>
			<form action="" onsubmit="return validate()" method="post">
				<table align="center">
					<tr>
						<td>Name: </td>
						<td><input type="text" id="name" name="name" value="" placeholder="Name"></td>
						
					</tr>
					<tr>
						<td>Username: </td>
						<td><input type="text" id="username" name="username" value="" placeholder="Username"></td>
					</tr>
					<tr>
						<td>Email: </td>
						<td><input type="text" id="email" name="email" value="" placeholder="Email"></td>
						
					</tr>
					<tr>
						<td>Phone Number: </td>
						<td><input type="tel" id="number" name="number" value="" placeholder="Phpne number"></td>
						
					</tr>
					<tr>
						<td>Nid: </td>
						<td><input type="number" id="nid" name="nid" value="" placeholder="nid"></td>
						
					</tr>
					<tr>
						<td>Password: </td>
						<td><input type="password" id="password" name="password" value="" placeholder="Password"></td>
					</tr>
					
					<tr>
						<td>Gender: </td>
						<td><input type="radio" id="male" value="Male" name="gender"> Male <input id="female" name="gender"  value="Female" type="radio"> Female</td>
					</tr>
					
						<td align="right" colspan="2"><input type="submit" value="Register"></td>
					</tr>
				</table>
			</form>
		</fieldset>
	</body>
</html>