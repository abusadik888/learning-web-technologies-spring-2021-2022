
<html>
<head>
    <link rel="stylesheet" href="style.css">


</head>
<body>

<form method="POST" onsubmit="return loginvalidation()" action="">
		<table align="center">

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">ERestaurant</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </div>



</body>
</html>