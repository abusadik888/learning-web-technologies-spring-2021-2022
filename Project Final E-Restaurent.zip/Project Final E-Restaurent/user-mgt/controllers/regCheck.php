<?php 
	session_start();
	require('../models/userModel.php');
	
	if(isset($_REQUEST['submit'])){
		
		$username = $_REQUEST['username'];
		$password = $_REQUEST['password'];
		$email = $_REQUEST['email'];
		$name = $_REQUEST['name'];
		$location = $_REQUEST['location'];
		$phone = $_REQUEST['phone'];
		$image = $_REQUEST['image'];

		if($username!=null && $password!=null && $email!=null && $name!=null && $location!=null && $phone!=null && $image!=null)
			{
		

			$status = signup($username, $password, $email, $name, $location, $phone, $image);
			if($status)
			{
				header('location: ../views/login.php');			
			}
		else{
				header('location: ../views/reg.php');
			}
	
			
		}else{
			echo "null submission";
		}
	}
?>
