<?php 
	session_start();
	require('../models/userModel.php');
	
	if(isset($_REQUEST['submit'])){
		
		$foodname = $_REQUEST['foodname'];
		$sellprice = $_REQUEST['sellprice'];
		$month = $_REQUEST['month'];

		if($foodname != null && $sellprice != null && $month != null)
			{
		

			$status = income($foodname, $sellprice, $month);
			if($status)
			{
				header('location: ../views/manager.php');			
			}
		else{
				echo("Not Perform");
			}
	
			
		}else{
			echo "null submission";
		}
	}
?>
