<?php 
	session_start();
	require('../models/userModel.php');

	if(isset($_REQUEST['submit'])){
		$username = $_REQUEST['username'];
		$password = $_REQUEST['password'];

		if($username != null && $password != null){

			$status = changepassword($username, $password);

				if($status){
					$_SESSION['status'] = true;
					setcookie('status', 'true', time()+3600, '/');
					header('location: ../views/login.php');
				}else{
					header('location: ../views/changepassword.php?msg=error');
				}


		}else{
			echo "null submission";
		}
	}
?>
