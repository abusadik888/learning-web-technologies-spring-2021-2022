<?php 
	session_start();
	require('../models/userModel.php');
	
	if(isset($_REQUEST['submit'])){
		
		$foodcode = $_REQUEST['foodcode'];
		$foodname = $_REQUEST['foodname'];
		$foodprice = $_REQUEST['foodprice'];
		$foodtype = $_REQUEST['foodtype'];

		if($foodcode != null && $foodname != null && $foodprice != null && $foodtype != null)
			{
		

			$status = addfood($foodcode, $foodname, $foodprice, $foodtype);
			if($status)
			{
				header('location: ../views/food menu.php');			
			}
		else{
				header('location: ../views/addfoodmenu.php');
			}
	
			
		}else{
			echo "null submission";
		}
	}
?>
