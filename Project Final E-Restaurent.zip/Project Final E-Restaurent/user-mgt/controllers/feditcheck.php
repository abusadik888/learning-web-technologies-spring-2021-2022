<?php 
	session_start();
	require('../models/userModel.php');

	if(isset($_REQUEST['submit']))
	{
		$foodname = $_REQUEST['foodname'];
		$foodprice = $_REQUEST['foodprice'];

		if($foodname != null && $foodprice != null)
		{

			$status = editfood($foodname, $foodprice);

				if($status)
			{
				header('location: ../views/food menu.php');			
			}
		else{
				header('location: ../views/fedit.php');
			}
	
			
		}
	else{
			echo "null submission";
		}
	}
?>