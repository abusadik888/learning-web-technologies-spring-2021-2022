<?php 
	session_start();
	require('../models/userModel.php');
	
	if(isset($_REQUEST['submit'])){

	$foodname = $_REQUEST['foodname'];	
	$foodcode = $_REQUEST['foodcode'];
	

		if($foodname != null &&  $foodcode != null )
			{
		

			$status = deletefood( $foodname , $foodcode);
			if($status)
			{
				header('location: ../views/food menu.php');			
			}
		else{
				header('location: ../views/fdelete.php');
			}
	
			
		}else{
			echo "null submission";
		}
	}
?>
