<?php 

	require('db.php');

	function login($username, $password){
		$con = getConnection();

		$sql = "select * from user where username='{$username}' and password='{$password}'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result)){
			return true;
		}else{
			return false;
		}
	}

	function signup($username, $password, $email,$name,$location,$phone,$image)
	{
		$con = getConnection();
		$sql = "insert into user values('{$username}', '{$password}', '{$email}','{$name}', '{$location}', '{$phone}', '{$image}')";

		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}

function changepassword($username,$password)
	{
		$con = getConnection();
		$sql = "update test set password = '$password' where username='$username'";

		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}

function addfood($foodcode,$foodname,$foodprice,$foodtype)
	{
		$con = getConnection();
		$sql = "insert into food values('{$foodcode}', '{$foodname}', '{$foodprice}', '{$foodtype}')";

		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}

	function editfood($foodname,$foodprice)
	{
		$con = getConnection();
		$sql = "update food set foodprice = '{$foodprice}' where foodname= '{$foodname}'" ;

		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}
function deletefood($foodname,$foodcode)
	{
		$con = getConnection();
		$sql = "delete from food where foodname = '{$foodname}'";

		if(mysqli_query($con, $sql)){
			return $sql;
		}else{
			return false;
		}
	}

function income($foodname, $sellprice, $month)
	{
		$con = getConnection();
		$sql = "insert into finance values('{$foodname}', '{$sellprice}', '{$month}','')";

		if(mysqli_query($con, $sql)){
			return true;
		}else{
			return false;
		}
	}


?>