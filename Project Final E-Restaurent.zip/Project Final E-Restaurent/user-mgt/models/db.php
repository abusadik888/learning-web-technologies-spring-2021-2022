<?php 

function getConnection(){
		$host = "localhost";
		$dbname= "E-restaurant";
		$dbuser = "root";
		$dbpass = "";

		$con = mysqli_connect($host, $dbuser, $dbpass, $dbname);
		return $con;
	}

?>